from django.shortcuts import render
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin


# Create your views here.
def home(request):
    url = "https://www.ebay.com/sch/i.html?_nkw=jewelry&_sop=12#home"
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "html.parser")
    cards = soup.find_all("div", class_="s-item__info")[:12]

    scraped_data = []
    for card in cards:
        img_cards = card.find_all("div", class_="s-item__wrapper clearfix")
        title_element = card.find("div", class_="s-item__title")
        product_price = card.find("span", class_="s-item__price")
        purchase_options = card.find(
            "span", class_="s-item__purchase-options s-item__purchaseOptions"
        )

        title = title_element.text.strip() if title_element else "Title not found"
        options = (
            purchase_options.text.strip() if purchase_options else "options not found"
        )
        price = product_price.text.strip() if product_price else "Description not found"
        scraped_data.append(
            {"title": title, "purchase_options": options, "product_price": price }
        )
    context = {"info": scraped_data}
    return render(request, "home.html", context)
